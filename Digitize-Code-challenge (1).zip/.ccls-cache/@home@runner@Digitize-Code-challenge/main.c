#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#define max 200
#define keyLength 4
#define wordLength 20

typedef struct Node Node;
struct Node {
  char key[keyLength + 1];
  char word[wordLength + 1];
  int wordLen;
  Node *next;
};
//use this to save the node
Node availableNode [max];
int dictSize = 0;

typedef struct Dictionary Dictionary;
struct Dictionary{
  Node* head;
};

//creat dictionary
Dictionary dict;
bool caseSensitive = true;
//searchResult was use to deposit match entreis
char searchResult [max][wordLength+1];
int resultSize = 0;

//insert a node into dictionary
//return true if success
//return false if duplicate encounter
bool insert(Node* target){
  if (dict.head == NULL){
    dict.head = target;
    return true;
  }
  else{
    if (strcmp(target->key, dict.head->key) < 0){
      target->next = dict.head;
      dict.head = target;
      return true;
    }
    else if(strcmp(target->word, dict.head->word) == 0){
      //duplicate
      return false;
    }
    else{
      Node* traversal = dict.head->next;
      Node* preNode = dict.head;
      //loop through the link list to find a position to insert
      while(traversal != NULL && strcmp(target->key, traversal->key) > 0){
        preNode = preNode->next;
        traversal = traversal ->next;
      }

      //to the end of link list
      if(traversal == NULL){
        preNode->next = target;
        return true;
      }
      //this is not a duplicate word
      if(traversal != NULL && strcmp(traversal->word, target->word) != 0){
        target->next = traversal;
        preNode ->next = target;
        return true;
      }
      
    }  
  }
  return false;
}

//convert str into lower case
char * strlwr(char* str){
  int i = 0;
  for(int i = 0; str[i] != '\0'; i++){
    if(str[i] >= 'A' && str[i] <= 'Z'){     
        str[i] = str[i] - 'A' + 'a';
    }
  }
  return str;
}

//search in the dictionary and save the matches in searchResult array
void search(char*key, bool caseSenitive){
  Node* travesalNode = dict.head;
  if(caseSenitive == true){
    
    while(travesalNode != NULL){
      if (strcmp(travesalNode->key, key) < 0 ){
          //go next
      }
      else if(strcmp(travesalNode->key, key) == 0){
          //match
          //add to result
          strcpy(searchResult[resultSize], travesalNode->word);
          resultSize++;
      }
      else if(strcmp(travesalNode->key, key) > 0 && strlen(key) <= strlen(travesalNode->key)){
          int keySize = strlen(key);
          char temp[keySize + 1];
          //copy substr of searching key into temp
          strncpy(temp, travesalNode->key,keySize);
          //it seems strncpy won't place null at the end, so i do it manually
          temp[keySize] = '\0';
          //printf("%s\n",temp);
          //subkey match
          if(strcmp(temp, key) == 0){
            //add to result
            strcpy(searchResult[resultSize], travesalNode->word);
            resultSize++;
          }
          
      }
      travesalNode = travesalNode->next;
    }
  } 
  else{
    //case insensitive search
    char lowCaseTargetKey[5];
    strcpy(lowCaseTargetKey, strlwr(key));
    //printf("low case of input key %s\n",lowCaseTargetKey);
    lowCaseTargetKey[4] = '\0';
    while(travesalNode != NULL){
      char lowCaseKey[5];
      strcpy(lowCaseKey, strlwr(travesalNode->key));
      lowCaseKey[4] = '\0';
      
      //printf("low case of travesal key %s\n",lowCaseKey);
      if(strcmp(lowCaseKey, lowCaseTargetKey) < 0){
        //go next;
      }
      else if(strcmp(lowCaseKey, lowCaseTargetKey) == 0){
        //key match
        strcpy(searchResult[resultSize], travesalNode->word);
        resultSize++;
      }
      else if(strcmp(lowCaseKey, lowCaseTargetKey) > 0 && strlen(lowCaseTargetKey) <= strlen(lowCaseKey)){
          //subkey match
          int keySize = strlen(lowCaseTargetKey);
          char temp[keySize + 1];
          //copy substr of searching key into temp
          strncpy(temp, lowCaseKey,keySize);
          //it seems strncpy won't place null at the end, so i do it manually
          temp[keySize] = '\0';
          //printf("%s\n",temp);
          if(strcmp(temp, lowCaseTargetKey) == 0){
            //add to result
            strcpy(searchResult[resultSize], travesalNode->word);
            resultSize++;
          }
      }
      travesalNode = travesalNode ->next;
    }
  }
  return;
}

void buildDictionary(char* str){
  //parse the string
  int inputLen = strlen(str);
  char parsingWord [wordLength+1];
  char cur_len = 0;
  dict.head = NULL;
  
  for(int i = 0; i < inputLen; i++){
    
    if((str[i] >= 65 && str[i] <= 90) || (str[i] >= 97 && str[i] <= 122)){
      
      parsingWord[cur_len] = str[i];
      cur_len ++;
    }
    else{
      if(cur_len > 0){
        parsingWord[cur_len] = '\0';

        //when all available node are used
        if( dictSize >= max) break;
        
        //printf("%s\n",parsingWord);
        //use available node
        Node* newNode = &availableNode[dictSize];
        if(strlen(parsingWord) > 4){
          char temp [5];
          strncpy(temp, parsingWord, 4);
          temp[4] = '\0';
          strcpy(newNode->key, temp);
        }
        else{
          strcpy(newNode->key, parsingWord);
        }
        strcpy(newNode->word, parsingWord);
        newNode->wordLen = strlen(parsingWord);
        newNode->next = NULL;
        //printf("this new node has key: %s, word: %s, wordlen: %d \n", newNode->key, newNode->word, newNode->wordLen);
        
        if(insert(newNode)){
          dictSize ++;
          //insert success, otherwise use the same node for next word
        }
        cur_len = 0;
      }
      else{
        continue;
      }
    }
  }
}

void instruction(){
  printf("Enter $exit to exit the program\n");
  printf("Enter $case sensitive to turn on case sensitive search mode\n");
  printf("Enter $case insensitive to turn on case insensitive search mode\n");
  if(caseSensitive == true){
    printf("currently in case senitive mode\n");
  }
  else{
    printf("currently in case insenitive mode\n");
  }
  printf("Enter first four letters of the word to search in the dictionary(This should be at length 1 - 4).\n");
  printf("Enter $add to add word into current dictionary. currently contain %d words, max limit is %d\n", dictSize, max);
  printf("Enter $delete to delete the current dictionary\n");
  printf("Enter $instruction to see this again\n\n");
}

void deleteDictionary(){
  dict.head = NULL;
  dictSize = 0;
  resultSize = 0;
}

int main(void) {
  printf("Enter a sentence to build dictionary\n");
  printf("Notice that this sentence should not be over %d characters, and each word shouldn't excess %d characters\n\n", max, wordLength);
  char str[max+2];
  // get input from std input
  fgets(str, max, stdin);
  
  // display value in std output
  //puts(str);

  //build dictionary on standard input
  buildDictionary(str);

  printf("\n");
  Node* travesal = dict.head;

  /*while(travesal != NULL){
    printf("This is a node of %s with key %s, len of %d\n", travesal->word, travesal->key, travesal->wordLen);
    travesal = travesal->next;
  }*/

  instruction();
  
  bool exit = false;
  
  while(!exit){
    char input[wordLength+2]; 
    //fget will get new line as well
    fgets(input, wordLength+2, stdin);
    //strlen will not count \0, therefore new line will be in the last position
    int inputSize = strlen(input);
    if(input[inputSize-1] == '\n'){
      input[inputSize-1] = '\0';
    }
    
    if(strcmp(input, "$exit") == 0){
      exit = true;
      break;
    }
    else if(strcmp(input, "$case sensitive") == 0){
      caseSensitive = true;
    }
    else if(strcmp(input, "$case insensitive") == 0){
      caseSensitive = false;
    }
    else if(strcmp(input, "$add") == 0){
      printf("Enter a word(No more than %d characters\n", wordLength);
      char addWord[wordLength+2];
      fgets(addWord, wordLength+2, stdin);

      if(addWord[strlen(addWord)-1] == '\n'){
        addWord[strlen(addWord) -1 ] = '\0';
      }
      
      if(dictSize == max){
        printf("Add failed, dictionary max limit reached\n");
      }
      else{
        Node* newNode = &availableNode[dictSize];
        dictSize++;
        if(strlen(addWord) > 4){
          strncpy(newNode->key, addWord, 4);
          newNode->key[4] = '\0';
        }
        else{
          strcpy(newNode->key, addWord);
        }
        strcpy(newNode->word, addWord);
        newNode->wordLen = strlen(addWord);
        newNode->next = NULL;
        insert(newNode);
        printf("Added successfully\n");
      }
    }
    else if(strcmp(input, "$instruction") == 0){
        instruction();
    }
    else if(strcmp(input, "$delete") == 0){
        deleteDictionary();
        printf("delete successful\n\n");
    }
    else{
      //search word
      search(input, caseSensitive);
      //print results
      printf("\nOutput:\n");
      if(resultSize == max){
        for(int i = 0; i < max; i ++){
          printf("%s\n", searchResult[i]);
        }
        printf("\n");
      }
      else if(resultSize == 0){
        printf("No matche\n\n");
      }
      else{
        //$$$$ mark the end of the search result
        strcpy(searchResult[resultSize], "$$$$");
        int i = 0;
        while(strcmp(searchResult[i], "$$$$") != 0){
          printf("%s\n",searchResult[i]);
          i++;
        }
        printf("\n");
      }
      resultSize = 0;
    }
  }
  return 0;
}